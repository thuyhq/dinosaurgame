var random_name = require('node-random-name');

module.exports = {
  createBot: function () {
    // whatever
    var socket = require('socket.io-client')('http://localhost:1339');
    var obj = new Object();
    var botName = random_name();
    if (botName.length > 15) {
      botName = botName.substring(0, 15);
    }
    obj.name = botName;
    obj.room = "global";
    obj.type = "bot";
    var result = JSON.stringify(obj);
    socket.emit("register", result);
    socket.on("registerComplete", function(data){
      socket.emit('startMove', '');
    });
    var duration = getRndInteger(5000, 60000);
    // console.log(duration);
    setTimeout(function () {
      socket.disconnect();
    }, duration);
  }
};

function getRndInteger(min, max) {
    return Math.floor(Math.random() * (max - min + 1) ) + min;
}

// function createBot() {
//   // whatever
//   var socket = require('socket.io-client')('http://localhost:1338');
//   var obj = new Object();
//   obj.name = "abc123";
//   obj.room = "global";
//   obj.type = "bot";
//   var result = JSON.stringify(obj);
//   socket.emit("register", result);
//   setTimeout(function () {
//     socket.disconnect();
//   }, 10000);
// }
// createBot();
